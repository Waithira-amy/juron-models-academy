1:"$Sreact.fragment"
2:I[10545,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js"],"default"]
3:I[95431,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"b6TqeaGtYO8iupnmk_3Y8"}
