var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/1173_next_dist_esm_build_templates_app-route_0t10hs5.js")
R.c("server/chunks/juron-academy__next-internal_server_app_favicon_ico_route_actions_1rbxkxa.js")
R.m(10597)
module.exports=R.m(10597).exports
