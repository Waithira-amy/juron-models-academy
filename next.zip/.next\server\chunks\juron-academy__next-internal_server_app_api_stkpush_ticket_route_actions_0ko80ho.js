module.exports=[49975,(e,o,d)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_api_stkpush_ticket_route_actions_0ko80ho.js.map