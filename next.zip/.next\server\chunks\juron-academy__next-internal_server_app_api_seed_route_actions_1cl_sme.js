module.exports=[31371,(e,o,d)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_api_seed_route_actions_1cl_sme.js.map