module.exports=[66832,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_page_actions_0pw-9-u.js.map