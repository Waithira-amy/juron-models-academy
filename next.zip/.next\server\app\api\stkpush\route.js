var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stkpush/route.js")
R.c("server/chunks/[root-of-the-server]__0fjbf2w._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/juron-academy__next-internal_server_app_api_stkpush_route_actions_0mzt4d9.js")
R.m(93452)
module.exports=R.m(93452).exports
