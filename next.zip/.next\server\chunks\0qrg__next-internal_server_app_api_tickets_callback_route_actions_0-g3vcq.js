module.exports=[83719,(e,o,d)=>{}];

//# sourceMappingURL=0qrg__next-internal_server_app_api_tickets_callback_route_actions_0-g3vcq.js.map