1:"$Sreact.fragment"
2:I[77321,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js"],"ViewportBoundary"]
3:I[77321,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[76240,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Juron Models Academy"}],["$","meta","1",{"name":"description","content":"East Africa's premier institution for discovering, nurturing, and empowering models and creative talents."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"b6TqeaGtYO8iupnmk_3Y8"}
