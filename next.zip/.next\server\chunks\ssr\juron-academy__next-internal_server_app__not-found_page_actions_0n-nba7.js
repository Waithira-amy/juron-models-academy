module.exports=[39762,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app__not-found_page_actions_0n-nba7.js.map