module.exports=[92078,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_events_page_actions_0v7k2m7.js.map