module.exports=[79595,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_voting_%5Bregion%5D_page_actions_1bjo646.js.map