module.exports=[27031,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_admin_page_actions_0znvosr.js.map