module.exports=[72563,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app__global-error_page_actions_03phmix.js.map