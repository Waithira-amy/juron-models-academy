module.exports=[34322,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_voting_portal_page_actions_0cl6ctf.js.map