var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stkpush/ticket/route.js")
R.c("server/chunks/[root-of-the-server]__1-_bgr5._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/juron-academy__next-internal_server_app_api_stkpush_ticket_route_actions_0ko80ho.js")
R.m(93426)
module.exports=R.m(93426).exports
