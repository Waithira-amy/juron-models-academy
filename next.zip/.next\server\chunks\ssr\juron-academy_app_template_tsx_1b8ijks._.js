module.exports=[92418,a=>{"use strict";var b=a.i(91589);a.s(["default",0,function({children:a}){return(0,b.jsx)("div",{className:"animate-in fade-in duration-700 ease-out fill-mode-forwards",children:a})}])}];

//# sourceMappingURL=juron-academy_app_template_tsx_1b8ijks._.js.map