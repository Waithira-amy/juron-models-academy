var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tickets/route.js")
R.c("server/chunks/[root-of-the-server]__0m94khn._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/juron-academy__next-internal_server_app_api_tickets_route_actions_1mxklqq.js")
R.m(16398)
module.exports=R.m(16398).exports
