module.exports=[6985,(e,o,d)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_favicon_ico_route_actions_1rbxkxa.js.map