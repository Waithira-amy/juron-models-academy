module.exports=[86730,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_programs_page_actions_0gcbmdm.js.map