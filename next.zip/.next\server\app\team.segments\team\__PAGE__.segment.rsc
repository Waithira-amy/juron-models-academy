1:"$Sreact.fragment"
2:I[77061,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js","/_next/static/chunks/3-cd8-kn39g2m.js"],"default"]
3:I[5858,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js","/_next/static/chunks/3-cd8-kn39g2m.js"],"default"]
4:I[15130,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js","/_next/static/chunks/3-cd8-kn39g2m.js"],"default"]
5:I[77321,["/_next/static/chunks/0uobom2qht-e7.js","/_next/static/chunks/2k-hg54rfxc62.js"],"OutletBoundary"]
6:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"relative min-h-screen flex flex-col w-full overflow-hidden bg-slate-50","children":[["$","$L2",null,{}],["$","div",null,{"className":"flex-grow","children":["$","$L3",null,{}]}],["$","$L4",null,{}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/3-cd8-kn39g2m.js","async":true}]],["$","$L5",null,{"children":["$","$6",null,{"name":"Next.MetadataOutlet","children":"$@7"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"b6TqeaGtYO8iupnmk_3Y8"}
7:null
