module.exports=[720,(e,o,d)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_api_register_route_actions_0fy8yqz.js.map