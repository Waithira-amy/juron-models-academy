var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/applicants/route.js")
R.c("server/chunks/[root-of-the-server]__04d9gpc._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/0qrg__next-internal_server_app_api_admin_applicants_route_actions_1tct8lf.js")
R.m(10281)
module.exports=R.m(10281).exports
