module.exports=[30841,(e,o,d)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_api_callback_route_actions_05oxz5x.js.map