var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/register/route.js")
R.c("server/chunks/[root-of-the-server]__0wb9lco._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/[root-of-the-server]__0vb99qq._.js")
R.c("server/chunks/[root-of-the-server]__1s4h5l3._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/juron-academy__next-internal_server_app_api_register_route_actions_0fy8yqz.js")
R.m(64669)
module.exports=R.m(64669).exports
