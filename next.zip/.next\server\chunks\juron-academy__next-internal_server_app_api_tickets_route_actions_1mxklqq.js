module.exports=[34647,(e,o,d)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_api_tickets_route_actions_1mxklqq.js.map