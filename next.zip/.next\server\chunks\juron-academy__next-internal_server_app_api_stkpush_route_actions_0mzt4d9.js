module.exports=[40261,(e,o,d)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_api_stkpush_route_actions_0mzt4d9.js.map