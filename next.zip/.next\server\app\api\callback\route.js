var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/callback/route.js")
R.c("server/chunks/[root-of-the-server]__1iogw-m._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/juron-academy__next-internal_server_app_api_callback_route_actions_05oxz5x.js")
R.m(43030)
module.exports=R.m(43030).exports
