var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tickets/callback/route.js")
R.c("server/chunks/[root-of-the-server]__0n-d-73._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/0qrg__next-internal_server_app_api_tickets_callback_route_actions_0-g3vcq.js")
R.m(29058)
module.exports=R.m(29058).exports
