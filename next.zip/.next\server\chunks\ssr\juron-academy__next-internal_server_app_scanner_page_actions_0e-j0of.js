module.exports=[92284,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_scanner_page_actions_0e-j0of.js.map