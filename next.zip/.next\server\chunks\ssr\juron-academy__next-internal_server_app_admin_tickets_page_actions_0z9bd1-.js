module.exports=[51223,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_admin_tickets_page_actions_0z9bd1-.js.map