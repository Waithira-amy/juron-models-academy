module.exports=[75353,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_register_page_actions_1jaaraa.js.map