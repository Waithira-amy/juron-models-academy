var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__0a21nb_._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/juron-academy__next-internal_server_app_api_dashboard_route_actions_0ipi1-_.js")
R.m(24353)
module.exports=R.m(24353).exports
