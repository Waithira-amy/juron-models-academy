globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/b6TqeaGtYO8iupnmk_3Y8/_buildManifest.js",
    "static/b6TqeaGtYO8iupnmk_3Y8/_ssgManifest.js",
    "static/b6TqeaGtYO8iupnmk_3Y8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0bfkt2ooqvyv-.js",
    "static/chunks/0esxuemmibrms.js",
    "static/chunks/16wgtlc1mpq27.js",
    "static/chunks/1c8vswv7p7618.js",
    "static/chunks/turbopack-0_razak4wpmw_.js"
  ]
};
