var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/tickets/route.js")
R.c("server/chunks/[root-of-the-server]__1mbfq9m._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/0qrg__next-internal_server_app_api_dashboard_tickets_route_actions_0crciv3.js")
R.m(48266)
module.exports=R.m(48266).exports
