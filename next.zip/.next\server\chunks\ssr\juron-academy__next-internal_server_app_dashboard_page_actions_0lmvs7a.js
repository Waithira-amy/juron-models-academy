module.exports=[78956,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_dashboard_page_actions_0lmvs7a.js.map