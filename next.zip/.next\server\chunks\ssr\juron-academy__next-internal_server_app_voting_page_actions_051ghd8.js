module.exports=[79901,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_voting_page_actions_051ghd8.js.map