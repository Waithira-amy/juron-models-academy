module.exports=[40682,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_team_page_actions_0rv_ezj.js.map