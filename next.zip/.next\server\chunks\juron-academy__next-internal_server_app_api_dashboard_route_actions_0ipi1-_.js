module.exports=[27579,(e,o,d)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_api_dashboard_route_actions_0ipi1-_.js.map