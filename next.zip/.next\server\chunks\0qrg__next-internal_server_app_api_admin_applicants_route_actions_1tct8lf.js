module.exports=[72124,(e,o,d)=>{}];

//# sourceMappingURL=0qrg__next-internal_server_app_api_admin_applicants_route_actions_1tct8lf.js.map