module.exports=[85539,(a,b,c)=>{}];

//# sourceMappingURL=juron-academy__next-internal_server_app_about_page_actions_0-7avu9.js.map