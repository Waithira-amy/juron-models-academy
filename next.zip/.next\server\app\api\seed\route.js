var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/seed/route.js")
R.c("server/chunks/[root-of-the-server]__1lqvder._.js")
R.c("server/chunks/[root-of-the-server]__1-i6wfk._.js")
R.c("server/chunks/[root-of-the-server]__0fus0pq._.js")
R.c("server/chunks/juron-academy__next-internal_server_app_api_seed_route_actions_1cl_sme.js")
R.m(43495)
module.exports=R.m(43495).exports
